from fastapi import FastAPI, Request, HTTPException, Depends, Response
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from pydantic import BaseModel
import requests
import models
import database

app = FastAPI()

# DB 테이블 생성
models.Base.metadata.create_all(bind=database.engine)
templates = Jinja2Templates(directory="templates")

# DB 세션 의존성
def get_db():
    db = database.SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Pydantic 모델
class UserData(BaseModel):
    username: str
    password: str

class RouteRequest(BaseModel):
    startX: float  # 경도 (Longitude)
    startY: float  # 위도 (Latitude)
    endX: float
    endY: float

# --- [페이지 렌더링 경로] ---

@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.get("/signup", response_class=HTMLResponse)
async def signup_page(request: Request):
    return templates.TemplateResponse("signup.html", {"request": request})

@app.get("/main", response_class=HTMLResponse)
async def main_page(request: Request):
    username = request.cookies.get("username")
    is_logged_in = True if username else False
    return templates.TemplateResponse("main.html", {
        "request": request, 
        "is_logged_in": is_logged_in,
        "username": username
    })

@app.get("/map", response_class=HTMLResponse)
async def map_page(request: Request):
    return templates.TemplateResponse("map.html", {"request": request})

# --- [API 엔드포인트] ---

@app.post("/api/signup")
async def signup(data: UserData, db: Session = Depends(get_db)):
    db_user = db.query(models.User).filter(models.User.username == data.username).first()
    if db_user:
        raise HTTPException(status_code=400, detail="이미 존재하는 아이디입니다.")
    
    new_user = models.User(username=data.username, password=data.password)
    db.add(new_user)
    db.commit()
    return {"message": "signup success"}

@app.post("/api/login")
async def login(data: UserData, response: Response, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(
        models.User.username == data.username,
        models.User.password == data.password
    ).first()
    
    if not user:
        raise HTTPException(status_code=401, detail="아이디 또는 비밀번호가 틀렸습니다.")
    
    response.set_cookie(key="username", value=user.username)
    return {"message": "success"}

@app.post("/api/logout")
async def logout(response: Response):
    response.delete_cookie("username")
    return {"message": "logout success"}

# --- [카카오 모빌리티 경로 API 추가] ---

@app.post("/api/route")
async def get_route(data: RouteRequest):
    """
    카카오 모빌리티 Directions API를 호출하여 자동차 경로 데이터를 반환합니다.
    """
    # 1. 카카오 REST API 키 입력 (내 애플리케이션 > 앱 키 > REST API 키)
    KAKAO_REST_API_KEY = "3e426e9b88aebecf87be37d1e117ebdc" 
    
    # 2. API 엔드포인트 설정 (자동차 경로 탐색)
    url = "https://apis-navi.kakaomobility.com/v1/directions"
    
    # 3. 파라미터 구성 (origin, destination 형식은 '경도,위도')
    params = {
        "origin": f"{data.startX},{data.startY}",
        "destination": f"{data.endX},{data.endY}",
        "priority": "RECOMMEND",
        "road_details": "false"
    }
    
    headers = {
        "Authorization": f"KakaoAK {KAKAO_REST_API_KEY}",
        "Content-Type": "application/json"
    }
    
    try:
        # 카카오 API는 GET 방식을 사용합니다.
        response = requests.get(url, params=params, headers=headers)
        
        if response.status_code != 200:
            print(f"Kakao API Error: {response.status_code} - {response.text}")
            raise HTTPException(status_code=response.status_code, detail="카카오 경로 API 호출 실패")
            
        return response.json()
        
    except Exception as e:
        print(f"Server Error: {e}")
        raise HTTPException(status_code=500, detail="경로 계산 중 오류가 발생했습니다.")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)